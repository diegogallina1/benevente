# Anonymous supplementary archive

This archive accompanies the double-anonymous review version of the paper.
It contains the frozen protocol, annual and daily outputs, the four-arm
language-model sensitivity results, the historical universe and event panels,
and the programs required to inspect the calculations.

The language-model experiment is retrospective.  It is not evidence of
prospective alpha or absence of training-data contamination.  The production
contract keeps asset selection and portfolio weights deterministic; the model
only explains a sealed decision record.

Run `python tools/build_paper_release.py` from the extracted archive after
installing the dependencies described by the source imports.  The included
`MANIFEST.sha256` records the exact bytes submitted for review.
